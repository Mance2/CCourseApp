package app.slyworks.coursecorrect.models

/**
 * Created by Joshua Sylvanus, 3:00 PM, 12-Apr-23.
 */
data class CourseEntity(val title:String,
                        val details:String,
                        val content:String )