package app.slyworks.coursecorrect.base.utils


/**
 *Created by Joshua Sylvanus, 5:54 AM, 12-Apr-23.
 */

const val NOT_ANSWERED = -1

const val NETWORK_ERROR_MESSAGE = "you are currently offline. Please check your connection and try again"

const val KEY_ACTIVITY_COUNT = "app.slyworks.coursecorrect.KEY_ACTIVITY_COUNT"
const val KEY_HOME_ARGS = "app.slyworks.coursecorrect.KEY_HOME_ARGS"